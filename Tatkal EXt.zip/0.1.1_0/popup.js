// Main data structure
let bookingData = {
    irctc_credentials: {},
    journey_details: {},
    passenger_details: [],
    travel_preferences: {},
    other_preferences: {},
    mobileNumber: {},
    fare: {},
    payment: {},
    clickmode: {},
    vpa: {},
    CardDetails: {},
    ext_credentials: {}
  };
  
  // Initialize on window load
  window.addEventListener("load", () => {
    console.log("Extension loaded");
    loadUserData();
    
    // Card details handlers
    document.querySelector("#cardnumber").addEventListener("input", handleCardInput);
    document.querySelector("#cardexpiry").addEventListener("input", handleCardInput);
    document.querySelector("#cardcvv").addEventListener("input", handleCardInput);
    document.querySelector("#cardholder").addEventListener("input", handleCardInput);
    document.querySelector("#cardtype").addEventListener("change", handleCardInput);
  
    // Form field handlers
    document.querySelector("#irctc-login").addEventListener("change", setIRCTCUsername);
    document.querySelector("#irctc-password").addEventListener("change", setIRCTCPassword);
    document.querySelector("#ext-login").addEventListener("change", setExtUsername);
    document.querySelector("#ext-password").addEventListener("change", setExtPassword);
    document.querySelector("#from").addEventListener("change", setFromStation);
    document.querySelector("#to").addEventListener("change", setDestinationStation);
    document.querySelector("#journey-date").addEventListener("change", setJourneyDate);
    document.querySelector("#journey-class-input").addEventListener("change", setJourneyClass);
    document.querySelector("#quota-input").addEventListener("change", setQuota);
    document.querySelector("#train").addEventListener("change", setTrainNumber);
  
    // Passenger details handlers
    for (let passengerIndex = 0; passengerIndex < 6; passengerIndex++) {
      document.querySelector(`#passenger-name-${passengerIndex + 1}`).addEventListener("change", 
        (event) => setPassengerDetails(event, passengerIndex, "passenger"));
      document.querySelector(`#age-${passengerIndex + 1}`).addEventListener("change", 
        (event) => setPassengerDetails(event, passengerIndex, "passenger"));
      document.querySelector(`#passenger-gender-${passengerIndex + 1}`).addEventListener("change", 
        (event) => setPassengerDetails(event, passengerIndex, "passenger"));
      document.querySelector(`#passenger-berth-${passengerIndex + 1}`).addEventListener("change", 
        (event) => setPassengerDetails(event, passengerIndex, "passenger"));
    }
  
    // Other handlers
    document.querySelector("#mobileNumber").addEventListener("change", setMobileNumber);
    document.querySelector("#fare").addEventListener("change", setFare);
    document.querySelector("#payment").addEventListener("change", setPaymentMethod);
    document.querySelector("#clickmode").addEventListener("change", setClickMode);
    document.querySelector("#autoUpgradation").addEventListener("change", setOtherPreferences);
    document.querySelector("#confirmberths").addEventListener("change", setOtherPreferences);
    document.querySelector("#vpa").addEventListener("change", setVpaDetails);
    document.querySelector("#travelInsuranceOpted-1").addEventListener("change", setTravelPreferences);
    document.querySelector("#travelInsuranceOpted-2").addEventListener("change", setTravelPreferences);
    
    // Action buttons
    document.querySelector("#submit-btn").addEventListener("click", handleSubmit);
    document.querySelector("#load-btn-1").addEventListener("click", () => loadUserData());
    document.querySelector("#clear-btn").addEventListener("click", () => clearData());
    document.querySelector("#connect-btn").addEventListener("click", initiateBooking);
    document.querySelector("#register-btn").addEventListener("click", () => {
      window.location.href = "https://tatkal.freetesthub.in/";
    });
  
    // Initialize clock
    updateClock();
    setInterval(updateClock, 1000);
  });
  
  // Helper Functions
  function updateClock() {
    const now = new Date();
    const dateStr = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()}`;
    const timeStr = now.toLocaleTimeString("en-US", { hour12: false });
    const clockElement = document.querySelector("div.row.col-sm-12.h_head1 > span > strong");
    if (clockElement) clockElement.innerText = `${dateStr} - ${timeStr}`;
  }
  
  // Data Handling Functions
  function handleCardInput(event) {
    if (!bookingData.CardDetails) {
      bookingData.CardDetails = {};
    }
    bookingData.CardDetails[event.target.name] = event.target.value;
    console.log("Card details updated:", bookingData.CardDetails);
  }
  
  function setIRCTCUsername(event) {
    if (!bookingData.irctc_credentials) {
      bookingData.irctc_credentials = {};
    }
    bookingData.irctc_credentials.user_name = event.target.value;
    console.log("IRCTC username updated:", bookingData.irctc_credentials);
  }
  
  function setIRCTCPassword(event) {
    bookingData.irctc_credentials.password = event.target.value;
    console.log("IRCTC password updated");
  }
  
  function setExtUsername(event) {
    if (!bookingData.ext_credentials) {
      bookingData.ext_credentials = {};
    }
    bookingData.ext_credentials.userID = event.target.value;
    console.log("Extension username updated:", bookingData.ext_credentials);
  }
  
  function setExtPassword(event) {
    bookingData.ext_credentials.ext_password = event.target.value;
    console.log("Extension password updated");
  }
  
  function setFromStation(event) {
    bookingData.journey_details.from = event.target.value;
  }
  
  function setDestinationStation(event) {
    bookingData.journey_details.to = event.target.value;
  }
  
  function setJourneyDate(event) {
    bookingData.journey_details.date = event.target.value;
  }
  
  function setJourneyClass(event) {
    bookingData.journey_details["class"] = event.target.value;
    document.querySelector("#journey-class-input").value = event.target.value;
  }
  
  function setQuota(event) {
    bookingData.journey_details.quota = event.target.value;
    document.querySelector("#quota-input").value = event.target.value;
  }
  
  function setTrainNumber(event) {
    bookingData.journey_details.train = event.target.value;
  }
  
  function setPassengerDetails(event, passengerIndex, type) {
    if (!bookingData.passenger_details[passengerIndex]) {
      bookingData.passenger_details[passengerIndex] = {};
    }
    bookingData.passenger_details[passengerIndex][event.target.name] = event.target.value;
  }
  
  function setMobileNumber(event) {
    bookingData.mobileNumber.mobileNumber = event.target.value;
  }
  
  function setFare(event) {
    bookingData.fare.fare = event.target.value;
  }
  
  function setPaymentMethod(event) {
    bookingData.payment.payment = event.target.value;
  }
  
  function setClickMode(event) {
    bookingData.clickmode.clickmode = event.target.value;
  }
  
  function setOtherPreferences(event) {
    if (!bookingData.other_preferences) {
      bookingData.other_preferences = {};
    }
    bookingData.other_preferences[event.target.name] = 
      event.target.type === "checkbox" ? event.target.checked : event.target.value;
  }
  
  function setVpaDetails(event) {
    if (!bookingData.vpa) {
      bookingData.vpa = {};
    }
    bookingData.vpa[event.target.name] = event.target.value;
  }
  
  function setTravelPreferences(event) {
    if (!bookingData.travel_preferences) {
      bookingData.travel_preferences = {};
    }
    bookingData.travel_preferences[event.target.name] = 
      event.target.type === "checkbox" ? event.target.checked : event.target.value;
  }
  
  // Station Filter Functions
  function filterFromStations() {
    const input = document.getElementById("from-station-input");
    const filter = input.value.toUpperCase();
    const stationList = document.getElementById("from-station-list");
    const items = stationList.getElementsByTagName('li');
  
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const text = item.textContent || item.innerText;
      if (text.toUpperCase().indexOf(filter) > -1) {
        item.style.display = '';
      } else {
        item.style.display = "none";
      }
    }
  }
  
  function filterDestinationStations() {
    const input = document.getElementById("destination-station-input");
    const filter = input.value.toUpperCase();
    const stationList = document.getElementById("destination-station-list");
    const items = stationList.getElementsByTagName('li');
  
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const text = item.textContent || item.innerText;
      if (text.toUpperCase().indexOf(filter) > -1) {
        item.style.display = '';
      } else {
        item.style.display = "none";
      }
    }
  }
  
  // Data Operations
  function modifyUserData() {
    console.log("Original passenger data:", bookingData.passenger_details);
    
    bookingData.passenger_details = bookingData.passenger_details
      .filter(passenger => passenger?.name?.length > 0 && passenger?.age?.length > 0)
      .map(passenger => ({
        name: passenger.name,
        age: passenger.age,
        gender: passenger.gender || 'M',
        berth: passenger.berth || " ",
        food: 'D',
        nationality: 'IN'
      }));
    
    console.log("Processed passenger data:", bookingData.passenger_details);
  }
  
  function loadUserData() {
    chrome.storage.local.get(null, (data) => {
      console.log("Loading user data:", data);
      
      if (Object.keys(data).length === 0) {
        return;
      }
  
      // Populate form fields
      document.querySelector("#irctc-login").value = data.irctc_credentials?.user_name || '';
      document.querySelector("#irctc-password").value = data.irctc_credentials?.password || '';
      document.querySelector("#from").value = data.journey_details?.from || '';
      document.querySelector("#to").value = data.journey_details?.to || '';
      document.querySelector("#ext-login").value = data.ext_credentials?.userID || '';
      document.querySelector("#ext-password").value = data.ext_credentials?.ext_password || '';
      document.querySelector("#journey-date").value = data.journey_details?.date || '';
      document.querySelector("#journey-class-input").value = data.journey_details?.class || '';
      document.querySelector("#quota-input").value = data.journey_details?.quota || '';
      document.querySelector("#train").value = data.journey_details?.train || '';
      document.querySelector("#mobileNumber").value = data.mobileNumber?.mobileNumber || '';
      document.querySelector("#fare").value = data.fare?.fare || '';
      document.querySelector("#payment").value = data.payment?.payment || '';
      document.querySelector("#clickmode").value = data.clickmode?.clickmode || '';
  
      // Populate passenger details
      data.passenger_details?.forEach((passenger, index) => {
        document.querySelector(`#passenger-name-${index + 1}`).value = passenger?.name || '';
        document.querySelector(`#age-${index + 1}`).value = passenger?.age || '';
        document.querySelector(`#passenger-gender-${index + 1}`).value = passenger?.gender || 'M';
        document.querySelector(`#passenger-berth-${index + 1}`).value = passenger?.berth || '';
      });
  
      // Populate checkboxes and radio buttons
      if (data.travel_preferences?.travelInsuranceOpted) {
        const selector = data.travel_preferences.travelInsuranceOpted === "yes" ? 1 : 2;
        document.querySelector(`#travelInsuranceOpted-${selector}`).checked = true;
      }
  
      if (data.other_preferences) {
        document.querySelector("#autoUpgradation").checked = data.other_preferences.autoUpgradation || false;
        document.querySelector("#confirmberths").checked = data.other_preferences.confirmberths || false;
      }
  
      if (data.vpa) {
        document.querySelector("#vpa").value = data.vpa.vpa || '';
      }
  
      if (data.CardDetails) {
        document.querySelector("#cardnumber").value = data.CardDetails.cardnumber || '';
        document.querySelector("#cardexpiry").value = data.CardDetails.cardexpiry || '';
        document.querySelector("#cardcvv").value = data.CardDetails.cardcvv || '';
        document.querySelector("#cardholder").value = data.CardDetails.cardholder || '';
        document.querySelector("#cardtype").value = data.CardDetails.cardtype || '';
      }
  
      bookingData = data;
    });
  }
  
  function clearData() {
    if (confirm("Do you want to clear all data?")) {
      chrome.storage.local.clear();
      document.querySelector("form").reset();
      bookingData = {
        irctc_credentials: {},
        journey_details: {},
        passenger_details: [],
        travel_preferences: {},
        other_preferences: {},
        mobileNumber: {},
        fare: {},
        payment: {},
        clickmode: {},
        vpa: {},
        CardDetails: {},
        ext_credentials: {}
      };
      console.log("Data cleared");
    }
  }
  
  // Booking Functions
  async function initiateBooking() {
    console.log("Initiating booking process");
    
    const isAuthenticated = await checkUser(
      bookingData.ext_credentials.userID, 
      bookingData.ext_credentials.ext_password
    );
  
    if (isAuthenticated) {
      alert("Authentication successful");
      startBookingProcess();
    } else {
      console.log("Authentication failed");
      window.open("https://tatkal.freetesthub.in/", "_blank");
    }
  }
  
  function startBookingProcess() {
    chrome.runtime.sendMessage({
      msg: {
        type: "activate_script",
        data: bookingData
      },
      sender: "popup",
      id: "irctc"
    }, (response) => {
      console.log("Booking response:", response);
    });
  }
  
  // Authentication
  async function checkUser(username, password) {
    const SHEET_ID = "11LY8SkwB_q_ccibbi_im1SkZJcZvrgN3Md7rnJHt6TI";
    const API_KEY = "AIzaSyACI1H2zJYGw_f0lzV9K0BA30SBw6vi03E";
    const SHEET_NAME = "UserDatabase";
  
    try {
      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${SHEET_NAME}?` +
        `majorDimension=ROWS&valueRenderOption=FORMATTED_VALUE&` +
        `dateTimeRenderOption=FORMATTED_STRING&key=${API_KEY}`
      );
  
      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`);
      }
  
      const { values: rows = [] } = await response.json();
      
      if (rows.length < 2) {
        console.warn("No user data found in sheet");
        return false;
      }
  
      // Find column indexes
      const headers = rows[0];
      const usernameCol = headers.indexOf("extusername");
      const passwordCol = headers.indexOf("password");
      const statusCol = headers.indexOf("paymentStatus");
  
      if (usernameCol === -1 || passwordCol === -1 || statusCol === -1) {
        console.error("Required columns not found in sheet");
        return false;
      }
  
      // Check credentials
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (row[usernameCol] === username && 
            row[passwordCol] === password && 
            (row[statusCol] === "Success" || row[statusCol] === "captured")) {
          return true;
        }
      }
  
      return false;
  
    } catch (error) {
      console.error("Authentication error:", error);
      return false;
    }
  }
  
  // Time Handling
  document.addEventListener("DOMContentLoaded", () => {
    const timeInputs = [
      document.getElementById("click-time1"), 
      document.getElementById("click-time2")
    ];
  
    // Load saved times
    function loadSavedTimes() {
      chrome.storage.sync.get(["clickTime1", "clickTime2"], (data) => {
        if (data.clickTime1) {
          document.getElementById("click-time1").value = data.clickTime1;
        }
        if (data.clickTime2) {
          document.getElementById("click-time2").value = data.clickTime2;
        }
      });
    }
  
    // Format time input
    function formatTimeInput(event) {
      let value = event.target.value.replace(/[^0-9]/g, '');
      if (value.length > 2 && value.length <= 4) {
        value = value.slice(0, 2) + ':' + value.slice(2);
      } else if (value.length > 4) {
        value = value.slice(0, 2) + ':' + value.slice(2, 4) + ':' + value.slice(4, 6);
      }
      event.target.value = value;
    }
  
    // Set up time inputs
    timeInputs.forEach(input => {
      if (input) input.addEventListener("input", formatTimeInput);
    });
  
    // Save times
    document.getElementById("save-time").addEventListener("click", () => {
      const time1 = document.getElementById("click-time1").value;
      const time2 = document.getElementById("click-time2").value;
      
      chrome.storage.sync.set({
        clickTime1: time1,
        clickTime2: time2
      }, () => {
        alert(`Times saved: ${time1} and ${time2}`);
      });
    });
  
    loadSavedTimes();
  });
  
  // Input Validation
  document.getElementById("mobileNumber").addEventListener("input", function() {
    this.value = this.value.replace(/[^0-9]/g, '');
    const errorElement = document.getElementById("error-message");
    if (this.value.length > 10) {
      errorElement.innerText = "Mobile number cannot exceed 10 digits.";
    } else {
      errorElement.innerText = '';
    }
  });
  
  // Date Input Handling
  const dateInput = document.getElementById("journey-date");
  if (dateInput) {
    dateInput.addEventListener("input", function(event) {
      let value = event.target.value.replace(/[^0-9]/g, '');
      if (value.length >= 3 && value.length <= 4) {
        value = value.slice(0, 2) + '/' + value.slice(2);
      } else if (value.length >= 5) {
        value = value.slice(0, 2) + '/' + value.slice(2, 4) + '/' + value.slice(4, 8);
      }
      event.target.value = value;
    });
  
    dateInput.addEventListener("keydown", function(event) {
      if (event.key === "Backspace" && event.target.value.endsWith('/')) {
        event.target.value = event.target.value.slice(0, -1);
      }
    });
  }
  
  // Payment Method Toggle
  const paymentSelect = document.getElementById("payment");
  const vpaField = document.getElementById("vpa");
  const cardDetails = document.getElementById("carddetails");
  
  if (paymentSelect) {
    paymentSelect.addEventListener("change", () => {
      const method = paymentSelect.value;
      if (method === "irctc upi" || method === "paytm upi") {
        vpaField.hidden = false;
        cardDetails.hidden = true;
      } else if (method === "dbt") {
        cardDetails.hidden = false;
        vpaField.hidden = true;
      } else {
        vpaField.hidden = true;
        cardDetails.hidden = true;
      }
    });
  }
  
  // Submit Handler
  function handleSubmit(event) {
    event.preventDefault();
    modifyUserData();
    chrome.storage.local.set({ finalData: bookingData }, () => {
      alert("Data saved successfully!");
    });
  }