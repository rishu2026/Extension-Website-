document.getElementById('submit').addEventListener('submit', function(event) {
  event.preventDefault();
  var inputVal = document.querySelector('input[name="uname"]').value;
  if (inputVal === "258025") {
      chrome.tabs.create({ url: 'popupCopy.html' });
  } else {
      alert("plz enter coorect password'.");
  }
});
